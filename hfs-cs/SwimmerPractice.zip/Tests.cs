using System;
using System.IO;
using System.Globalization;

namespace SwimmerPractice
{
    // קובץ נתון. משלימים את התרגילים ב־Program.cs וב־Swimmer.cs.
    // כל מערכי השחיינים בבדיקות אינם ריקים; אין בדיקות null או סגנון לא מוכר.
    public static class Tests
    {
        public static void RunAll()
        {
            Action[] sections = { Test01, Test02, Test03, Test04, Test05, Test06,
                Test07, Test08, Test09, Test10, Test11 };
            for (int i = 0; i < sections.Length; i++)
            {
                string number = (i + 1).ToString("00");
                try
                {
                    sections[i]();
                    Console.WriteLine(number + " PASSED");
                }
                catch (NotImplementedException ex)
                {
                    Console.WriteLine(number + " FAILED - " + Short(ex.Message) + " not implemented");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(number + " FAILED - " + Short(ex.Message));
                }
            }
        }

        private static Swimmer S(string name, string style, double record)
        {
            return new Swimmer(name, style, record);
        }

        private static Swimmer[] Team()
        {
            return new Swimmer[] {
                S("Noa", "backstroke", 29.4), S("Ido", "freestyle", 26.8),
                S("Maya", "freestyle", 25.7), S("Dan", "breaststroke", 34.2)
            };
        }

        private static void Test01()
        {
            Equal("Noa\n29.4", Capture(() => Program.ShowSwimmer(S("Noa", "backstroke", 29.4))), "ShowSwimmer");
            Equal("Ido\n26.8", Capture(() => Program.ShowSwimmer(S("Ido", "freestyle", 26.8))), "ShowSwimmer");
        }

        private static void Test02()
        {
            Swimmer a = S("A", "freestyle", 26.2);
            Equal(true, a.SameStyle(S("B", "freestyle", 28.1)), "same style");
            Equal(false, a.SameStyle(S("A", "backstroke", 26.2)), "different style");
            Equal(true, a.SameStyle(a), "same swimmer");
        }

        private static void Test03()
        {
            Swimmer a = S("A", "freestyle", 26.2);
            Equal(true, a.IsFasterInSameStyle(S("B", "freestyle", 26.8)), "lower time");
            Equal(false, a.IsFasterInSameStyle(S("B", "freestyle", 25.9)), "higher time");
            Equal(false, a.IsFasterInSameStyle(S("B", "freestyle", 26.2)), "equal times");
            Equal(false, a.IsFasterInSameStyle(S("B", "backstroke", 30.1)), "different style");
        }

        private static void Test04()
        {
            Equal("Noa\nIdo\nMaya\nDan", Capture(() => Program.PrintAllNames(Team())), "04a names/order");
            Equal("Ido\nMaya", Capture(() => Program.PrintFreestyleNames(Team())), "04b freestyle");
            Swimmer[] other = { S("Roni", "backstroke", 30.1), S("Tamar", "butterfly", 29.3) };
            Equal("Roni\nTamar", Capture(() => Program.PrintAllNames(other)), "04a names/order");
            Equal("", Capture(() => Program.PrintFreestyleNames(other)), "04b no freestyle");
        }

        private static void Test05()
        {
            Equal(2, Program.CountStyle(Team(), "freestyle"), "freestyle count");
            Equal(1, Program.CountStyle(Team(), "backstroke"), "backstroke count");
            Equal(0, Program.CountStyle(Team(), "butterfly"), "style absent");
            Swimmer[] one = { S("A", "butterfly", 28.4) };
            Equal(1, Program.CountStyle(one, "butterfly"), "one swimmer");
        }

        private static void Test06()
        {
            Swimmer[] team = { S("A", "freestyle", 28.9), S("B", "freestyle", 28.1), S("C", "freestyle", 28.6) };
            Number(28.1, Program.BestRecord(team), "minimum time");
            Swimmer[] first = { S("A", "backstroke", 29.2), S("B", "backstroke", 32.8) };
            Number(29.2, Program.BestRecord(first), "first is fastest");
            Swimmer[] last = { S("A", "freestyle", 30.5), S("B", "freestyle", 27.4) };
            Number(27.4, Program.BestRecord(last), "last is fastest");
            Swimmer[] one = { S("A", "butterfly", 31.7) };
            Number(31.7, Program.BestRecord(one), "one swimmer");
        }

        private static void Test07()
        {
            Swimmer[] team = { S("A", "freestyle", 28.9), S("B", "freestyle", 28.1), S("C", "freestyle", 28.6) };
            Equal("B", Program.FastestName(team), "name of fastest");
            Swimmer[] first = { S("First", "backstroke", 29.2), S("Last", "backstroke", 32.8) };
            Equal("First", Program.FastestName(first), "first is fastest");
            Swimmer[] last = { S("First", "freestyle", 30.5), S("Last", "freestyle", 27.4) };
            Equal("Last", Program.FastestName(last), "last is fastest");
            Swimmer[] one = { S("Only", "butterfly", 31.7) };
            Equal("Only", Program.FastestName(one), "one swimmer");
        }

        private static void Test08()
        {
            Equal("Maya", Program.FastestInStyle(Team(), "freestyle"), "fastest freestyle");
            Equal("Noa", Program.FastestInStyle(Team(), "backstroke"), "one matching swimmer");
            Swimmer[] mixed = { S("FastOther", "freestyle", 22.5), S("B", "backstroke", 32.1),
                S("C", "backstroke", 29.6), S("D", "butterfly", 27.8) };
            Equal("C", Program.FastestInStyle(mixed, "backstroke"), "ignore other styles");
        }

        private static void Test09()
        {
            Equal("", Program.FastestNameOrEmpty(Team(), "butterfly"), "style absent");
            Equal("Maya", Program.FastestNameOrEmpty(Team(), "freestyle"), "fastest freestyle");
            Swimmer[] mixed = { S("Other", "freestyle", 22.5), S("B", "backstroke", 32.1), S("C", "backstroke", 29.6) };
            Equal("C", Program.FastestNameOrEmpty(mixed, "backstroke"), "ignore other styles");
        }

        private static void Test10()
        {
            string[] styles = { "freestyle", "backstroke", "breaststroke", "butterfly" };
            for (int i = 0; i < styles.Length; i++)
            {
                int[] counts = { 2, 4, 1, 3 };
                int[] expected = { 2, 4, 1, 3 };
                expected[i]++;
                Program.AddToStyleCounts(counts, S("A", styles[i], 29.5));
                Counts(expected, counts, "10a " + styles[i]);
            }
            Counts(new int[] { 2, 1, 1, 0 }, Program.CountStyles(Team()), "10b all styles");
            Swimmer[] team = { S("A", "butterfly", 29.3), S("B", "butterfly", 30.1), S("C", "backstroke", 31.2) };
            Counts(new int[] { 0, 1, 0, 2 }, Program.CountStyles(team), "10b fresh counters");
        }

        private static void Test11()
        {
            Equal("Maya\nfreestyle: 2\nbackstroke: 1\nbreaststroke: 1\nbutterfly: 0",
                Capture(() => Program.ShowTeamSummary(Team())), "team summary");
            Swimmer[] other = { S("A", "backstroke", 30.2), S("B", "butterfly", 29.1) };
            Equal("none\nfreestyle: 0\nbackstroke: 1\nbreaststroke: 0\nbutterfly: 1",
                Capture(() => Program.ShowTeamSummary(other)), "summary/no freestyle");
        }

        private static string Capture(Action action)
        {
            TextWriter previous = Console.Out;
            using (StringWriter writer = new StringWriter(CultureInfo.InvariantCulture))
            {
                try
                {
                    Console.SetOut(writer);
                    action();
                }
                finally
                {
                    Console.SetOut(previous);
                }
                return writer.ToString().Replace("\r\n", "\n").TrimEnd('\n', '\r');
            }
        }

        private static void Equal<T>(T expected, T actual, string label)
        {
            if (!object.Equals(expected, actual))
                throw new Exception(label + ": expected " + Value(expected) + ", got " + Value(actual));
        }

        private static void Number(double expected, double actual, string label)
        {
            if (double.IsNaN(actual) || Math.Abs(expected - actual) > 0.000000001)
                throw new Exception(label + ": expected " + expected + ", got " + actual);
        }

        private static void Counts(int[] expected, int[] actual, string label)
        {
            if (actual == null)
                throw new Exception(label + ": expected int[4], got null");
            if (actual.Length != 4)
                throw new Exception(label + ": expected 4 counters, got " + actual.Length);
            for (int i = 0; i < 4; i++)
                Equal(expected[i], actual[i], label + " index " + i);
        }

        private static string Value(object value)
        {
            if (value == null) return "null";
            if (value is string) return "\"" + value.ToString().Replace("\n", " / ") + "\"";
            return value.ToString();
        }

        private static string Short(string message)
        {
            string line = message.Replace("\r", " ").Replace("\n", " / ");
            return line.Length <= 180 ? line : line.Substring(0, 177) + "...";
        }
    }
}
