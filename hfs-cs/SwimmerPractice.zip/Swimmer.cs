using System;

namespace SwimmerPractice
{
    public class Swimmer
    {
        private string name;
        private string style;
        private double record;

        // Best 50 m time in seconds, in the swimmer's strongest style. Lower is better.
        public Swimmer(string name, string style, double record)
        {
            this.name = name;
            this.style = style;
            this.record = record;
        }

        public string GetName()
        {
            return this.name;
        }

        public string GetStyle()
        {
            return this.style;
        }

        public double GetRecord()
        {
            return this.record;
        }

        // Exercise 02: Do this swimmer and other have the same style?
        public bool SameStyle(Swimmer other)
        {
            // TODO 02: Replace the following throw with your code.
            throw new NotImplementedException("02");
        }

        // Exercise 03: Same style, and this swimmer's time is strictly lower than other's.
        public bool IsFasterInSameStyle(Swimmer other)
        {
            // TODO 03: Reuse your SameStyle method.
            throw new NotImplementedException("03");
        }
    }
}
