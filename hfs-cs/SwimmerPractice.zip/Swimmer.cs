using System;

namespace SwimmerPractice
{
    public class Swimmer
    {
        private string name;
        private string style;
        private double record;

        // זמן בשניות ל־50 מטר בסגנון החזק של השחיין. זמן נמוך יותר טוב יותר.
        public Swimmer(string name, string style, double record)
        {
            this.name = name;
            this.style = style;
            this.record = record;
        }

        public string GetName()
        {
            return this.name;
        }

        public string GetStyle()
        {
            return this.style;
        }

        public double GetRecord()
        {
            return this.record;
        }

        // תרגיל 02: האם השחיין המפעיל והשחיין other מתמחים באותו סגנון?
        public bool SameStyle(Swimmer other)
        {
            // TODO 02: החליפו את שורת ה־throw במימוש שלכם.
            throw new NotImplementedException("02");
        }

        // תרגיל 03: אותו סגנון, ולמפעיל זמן נמוך ממש מזמנו של other.
        public bool IsFasterInSameStyle(Swimmer other)
        {
            // TODO 03: השתמשו גם בפעולה SameStyle שכתבתם.
            throw new NotImplementedException("03");
        }
    }
}
