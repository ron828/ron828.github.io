using System;
using System.Globalization;
using System.Text;

namespace SwimmerPractice
{
    public class Program
    {
        public static void Main()
        {
            // משאירים את ההגדרות ואת הקריאה לבדיקות כפי שהן.
            Console.OutputEncoding = Encoding.UTF8;
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
            Tests.RunAll();
        }

        // תרגיל 01: שמרו את השם ואת הזמן במשתנים, והדפיסו כל אחד בשורה נפרדת.
        public static void ShowSwimmer(Swimmer s)
        {
            // TODO 01: משתמשים בפעולות Get. לא מוסיפים כותרות לפלט.
            throw new NotImplementedException("01");
        }

        // תרגיל 04א: הדפיסו את כל השמות, לפי סדר המערך, שם בכל שורה.
        public static void PrintAllNames(Swimmer[] swimmers)
        {
            for (int i = 0; i < swimmers.Length; i++)
            {
                // TODO 04א: כתבו כאן את הוראת ההדפסה.
            }
            // לאחר ההשלמה, מחקו את השורה הבאה.
            throw new NotImplementedException("04a");
        }

        // תרגיל 04ב: הדפיסו רק שמות של שחייני freestyle, לפי סדר המערך.
        public static void PrintFreestyleNames(Swimmer[] swimmers)
        {
            for (int i = 0; i < swimmers.Length; i++)
            {
                // TODO 04ב: כתבו כאן תנאי ובתוכו הוראת הדפסה.
            }
            // לאחר ההשלמה, מחקו את השורה הבאה.
            throw new NotImplementedException("04b");
        }

        // תרגיל 05: החזירו את מספר השחיינים בסגנון המבוקש.
        public static int CountStyle(Swimmer[] swimmers, string style)
        {
            int count = 0;
            for (int i = 0; i < swimmers.Length; i++)
            {
                // TODO 05: בדקו את הסגנון ועדכנו את המונה כשצריך.
            }
            // החליפו את השורה הבאה ב־return count;
            throw new NotImplementedException("05");
        }

        // תרגיל 06: כל השחיינים במערך הזה באותו סגנון. החזירו זמן מינימלי.
        public static double BestRecord(Swimmer[] swimmers)
        {
            double best = swimmers[0].GetRecord();
            for (int i = 1; i < swimmers.Length; i++)
            {
                // TODO 06: בדקו אם מצאתם זמן טוב יותר, ועדכנו את best.
            }
            // החליפו את השורה הבאה ב־return best;
            throw new NotImplementedException("06");
        }

        // תרגיל 07: כל השחיינים באותו סגנון ויש בעל שיא יחיד. החזירו את שמו.
        public static string FastestName(Swimmer[] swimmers)
        {
            // TODO 07
            throw new NotImplementedException("07");
        }

        // תרגיל 08: המערך מעורב. קיים שחיין בסגנון המבוקש ויש בו מנצח יחיד.
        public static string FastestInStyle(Swimmer[] swimmers, string style)
        {
            // TODO 08א: מצאו שחיין ראשון בסגנון המתאים שישמש נקודת התחלה.
            // TODO 08ב: חפשו זמן טוב יותר רק בקרב שחיינים באותו סגנון.
            // החזירו את שם השחיין שמצאתם.
            throw new NotImplementedException("08");
        }

        // תרגיל 09: ייתכן שאין שחיין בסגנון המבוקש. במקרה הזה החזירו "".
        public static string FastestNameOrEmpty(Swimmer[] swimmers, string style)
        {
            // TODO 09: אפשר להיעזר בפעולות הקודמות לאחר בדיקה שיש התאמה.
            throw new NotImplementedException("09");
        }

        // נתון לתרגיל 10. אין צורך לשנות את הפעולה הזו.
        public static int StyleIndex(string style)
        {
            if (style == "freestyle") return 0;
            if (style == "backstroke") return 1;
            if (style == "breaststroke") return 2;
            return 3; // butterfly; כל הסגנונות בקלט הם אחד מארבעת הסגנונות הנתונים.
        }

        // תרגיל 10א: counts כבר קיים ואורכו 4. הוסיפו את השחיין למונה המתאים.
        public static void AddToStyleCounts(int[] counts, Swimmer s)
        {
            // TODO 10א: השתמשו ב־StyleIndex. מעדכנים את המערך שקיבלתם.
            throw new NotImplementedException("10a");
        }

        // תרגיל 10ב: החזירו מערך מונים חדש באורך 4, לפי סדר הסגנונות ב־StyleIndex.
        public static int[] CountStyles(Swimmer[] swimmers)
        {
            // TODO 10ב: צרו מערך, עברו על השחיינים והיעזרו ב־AddToStyleCounts.
            throw new NotImplementedException("10b");
        }

        // תרגיל 11: הדפיסו את המהיר ב־freestyle (או none), ואז את ארבעת המונים.
        public static void ShowTeamSummary(Swimmer[] swimmers)
        {
            // TODO 11: השתמשו ב־FastestNameOrEmpty וב־CountStyles.
            // הפלט המדויק והדוגמה מופיעים בדף התרגילים.
            throw new NotImplementedException("11");
        }
    }
}
