using System;
using System.Globalization;
using System.Text;

namespace SwimmerPractice
{
    public class Program
    {
        public static void Main()
        {
            // Keep these settings and the test call unchanged.
            Console.OutputEncoding = Encoding.UTF8;
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
            Tests.RunAll();
        }

        // Exercise 01: Store the name and time in variables. Print each on its own line.
        public static void ShowSwimmer(Swimmer s)
        {
            // TODO 01: Use the getters. Print values only, without labels.
            throw new NotImplementedException("01");
        }

        // Exercise 04a: Print all names in array order, one per line.
        public static void PrintAllNames(Swimmer[] swimmers)
        {
            for (int i = 0; i < swimmers.Length; i++)
            {
                // TODO 04a: Write the print statement here.
            }
            // Remove the following throw after completing this part.
            throw new NotImplementedException("04a");
        }

        // Exercise 04b: Print freestyle swimmers' names in array order.
        public static void PrintFreestyleNames(Swimmer[] swimmers)
        {
            foreach (Swimmer swimmer in swimmers)
            {
                // TODO 04b: Use swimmer. Add a condition and a print statement inside it.
            }
            // Remove the following throw after completing this part.
            throw new NotImplementedException("04b");
        }

        // Exercise 05: Return the number of swimmers with the requested style.
        public static int CountStyle(Swimmer[] swimmers, string style)
        {
            int count = 0;
            foreach (Swimmer swimmer in swimmers)
            {
                // TODO 05: Check swimmer's style and increase the counter when it matches.
            }
            // Replace the following throw with: return count;
            throw new NotImplementedException("05");
        }

        // Exercise 06: All swimmers have the same style. Return the lowest time.
        public static double BestRecord(Swimmer[] swimmers)
        {
            double best = swimmers[0].GetRecord();
            for (int i = 1; i < swimmers.Length; i++)
            {
                // TODO 06: Update best when you find a lower time.
            }
            // Replace the following throw with: return best;
            throw new NotImplementedException("06");
        }

        // Exercise 07: Same style, one fastest swimmer. Return that swimmer's name.
        public static string FastestName(Swimmer[] swimmers)
        {
            // TODO 07
            throw new NotImplementedException("07");
        }

        // Exercise 08: Mixed styles. A match exists, with one fastest swimmer in that style.
        public static string FastestInStyle(Swimmer[] swimmers, string style)
        {
            // TODO 08a: Find the first swimmer with the requested style.
            // TODO 08b: Look for a lower time only among swimmers with that style.
            // Return the selected swimmer's name.
            throw new NotImplementedException("08");
        }

        // Exercise 09: Return the fastest matching swimmer's name, or "" if no match exists.
        public static string FastestNameOrEmpty(Swimmer[] swimmers, string style)
        {
            // TODO 09: Check for a match, then reuse your earlier methods.
            throw new NotImplementedException("09");
        }

        // Provided for exercise 10. Keep this method unchanged.
        public static int StyleIndex(string style)
        {
            if (style == "freestyle") return 0;
            if (style == "backstroke") return 1;
            if (style == "breaststroke") return 2;
            return 3; // butterfly; input uses only the four given styles.
        }

        // Exercise 10a: counts already has 4 cells. Increase the matching counter.
        public static void AddToStyleCounts(int[] counts, Swimmer s)
        {
            // TODO 10a: Use StyleIndex. Update the array you received.
            throw new NotImplementedException("10a");
        }

        // Exercise 10b: Return 4 new counters in StyleIndex order.
        public static int[] CountStyles(Swimmer[] swimmers)
        {
            // TODO 10b: Create the array. Loop through the swimmers and call AddToStyleCounts.
            throw new NotImplementedException("10b");
        }

        // Exercise 11: Print the fastest freestyle name (or none), then the four counters.
        public static void ShowTeamSummary(Swimmer[] swimmers)
        {
            // TODO 11: Use FastestNameOrEmpty and CountStyles.
            // See the worksheet for the exact output format and an example.
            throw new NotImplementedException("11");
        }
    }
}
