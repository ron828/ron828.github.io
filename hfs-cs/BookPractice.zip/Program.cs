using System;
using System.Globalization;
using System.Text;

namespace BookPractice
{
    public class Program
    {
        public static void Main()
        {
            // Keep these settings and the test call unchanged.
            Console.OutputEncoding = Encoding.UTF8;
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
            Tests.RunAll();
        }

        // Exercise 01: Store pages and rating in variables. Print each on its own line.
        public static void ShowBook(Book b)
        {
            // TODO 01: Use the getters. Print values only, without labels.
            throw new NotImplementedException("01");
        }

        // Exercise 04a: Print each book's page count in array order, one per line.
        public static void PrintAllPages(Book[] books)
        {
            for (int i = 0; i < books.Length; i++)
            {
                // TODO 04a: Write the print statement here.
            }
            // Remove the following throw after completing this part.
            throw new NotImplementedException("04a");
        }

        // Exercise 04b: Print page counts for fantasy books only, in array order.
        public static void PrintFantasyPages(Book[] books)
        {
            foreach (Book book in books)
            {
                // TODO 04b: Use book. Add a condition and a print statement inside it.
            }
            // Remove the following throw after completing this part.
            throw new NotImplementedException("04b");
        }

        // Exercise 05: Return the number of books in the requested genre.
        public static int CountGenre(Book[] books, string genre)
        {
            int count = 0;
            foreach (Book book in books)
            {
                // TODO 05: Check book's genre and increase the counter when it matches.
            }
            // Replace the following throw with: return count;
            throw new NotImplementedException("05");
        }

        // Exercise 06: All books have the same genre. Return the highest rating.
        public static int MaxRating(Book[] books)
        {
            int best = books[0].GetRating();
            for (int i = 1; i < books.Length; i++)
            {
                // TODO 06: Update best when you find a higher rating.
            }
            // Replace the following throw with: return best;
            throw new NotImplementedException("06");
        }

        // Exercise 07: Same genre, one best-rated book. Return that book's page count.
        public static int BestRatedPages(Book[] books)
        {
            // TODO 07: Choose by rating; return pages.
            throw new NotImplementedException("07");
        }

        // Exercise 08: A matching book exists, with one best-rated book in that genre.
        public static int BestRatedPagesInGenre(Book[] books, string genre)
        {
            // TODO 08a: Find the first book in the requested genre.
            // TODO 08b: Look for a higher rating only among books in that genre.
            // Return the selected book's page count.
            throw new NotImplementedException("08");
        }

        // Exercise 09: Return the best-rated matching book's page count, or -1 if no match exists.
        public static int BestRatedPagesOrMinusOne(Book[] books, string genre)
        {
            // TODO 09: Check for a match, then reuse your earlier methods.
            throw new NotImplementedException("09");
        }

        // Provided for exercise 10. Keep this method unchanged.
        public static int GenreIndex(string genre)
        {
            if (genre == "fantasy") return 0;
            if (genre == "mystery") return 1;
            if (genre == "science") return 2;
            return 3; // biography; input uses only the four given genres.
        }

        // Exercise 10a: counts already has 4 cells. Increase the matching counter.
        public static void AddToGenreCounts(int[] counts, Book b)
        {
            // TODO 10a: Use GenreIndex. Update the array you received.
            throw new NotImplementedException("10a");
        }

        // Exercise 10b: Return 4 new counters in GenreIndex order.
        public static int[] CountGenres(Book[] books)
        {
            // TODO 10b: Create the array. Loop through the books and call AddToGenreCounts.
            throw new NotImplementedException("10b");
        }

        // Exercise 11: Print the best-rated fantasy book's page count (or none), then 4 counters.
        public static void ShowLibrarySummary(Book[] books)
        {
            // TODO 11: Use BestRatedPagesOrMinusOne and CountGenres.
            // See the worksheet for the exact output format and an example.
            throw new NotImplementedException("11");
        }
    }
}
