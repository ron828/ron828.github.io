using System;
using System.Globalization;
using System.Text;

namespace BookPractice
{
    public class Program
    {
        public static void Main()
        {
            // משאירים את ההגדרות ואת הקריאה לבדיקות כפי שהן.
            Console.OutputEncoding = Encoding.UTF8;
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
            Tests.RunAll();
        }

        // תרגיל 01: שמרו את מספר העמודים ואת הדירוג במשתנים, והדפיסו כל אחד בשורה.
        public static void ShowBook(Book b)
        {
            // TODO 01: משתמשים בפעולות Get. אין להוסיף כותרות לפלט.
            throw new NotImplementedException("01");
        }

        // תרגיל 04א: הדפיסו את מספר העמודים של כל ספר, לפי סדר המערך, אחד בשורה.
        public static void PrintAllPages(Book[] books)
        {
            for (int i = 0; i < books.Length; i++)
            {
                // TODO 04א: כתבו כאן את הוראת ההדפסה.
            }
            // לאחר ההשלמה, מחקו את השורה הבאה.
            throw new NotImplementedException("04a");
        }

        // תרגיל 04ב: הדפיסו מספרי עמודים של ספרי fantasy בלבד, לפי סדר המערך.
        public static void PrintFantasyPages(Book[] books)
        {
            for (int i = 0; i < books.Length; i++)
            {
                // TODO 04ב: כתבו כאן תנאי ובתוכו הוראת הדפסה.
            }
            // לאחר ההשלמה, מחקו את השורה הבאה.
            throw new NotImplementedException("04b");
        }

        // תרגיל 05: החזירו את מספר הספרים בסוגה המבוקשת.
        public static int CountGenre(Book[] books, string genre)
        {
            int count = 0;
            for (int i = 0; i < books.Length; i++)
            {
                // TODO 05: בדקו את הסוגה ועדכנו את המונה כשצריך.
            }
            // החליפו את השורה הבאה ב־return count;
            throw new NotImplementedException("05");
        }

        // תרגיל 06: כל הספרים באותה סוגה. החזירו את הדירוג הגבוה ביותר.
        public static int MaxRating(Book[] books)
        {
            int best = books[0].GetRating();
            for (int i = 1; i < books.Length; i++)
            {
                // TODO 06: בדקו אם מצאתם דירוג גבוה יותר, ועדכנו את best.
            }
            // החליפו את השורה הבאה ב־return best;
            throw new NotImplementedException("06");
        }

        // תרגיל 07: אותה סוגה, ספר יחיד בדירוג המרבי. החזירו את מספר עמודיו.
        public static int BestRatedPages(Book[] books)
        {
            // TODO 07: הדירוג קובע את הבחירה; מספר העמודים הוא הערך המוחזר.
            throw new NotImplementedException("07");
        }

        // תרגיל 08: קיים ספר בסוגה המבוקשת ויש בה ספר יחיד בדירוג המרבי.
        public static int BestRatedPagesInGenre(Book[] books, string genre)
        {
            // TODO 08א: מצאו ספר ראשון בסוגה המתאימה שישמש נקודת התחלה.
            // TODO 08ב: חפשו דירוג גבוה יותר רק בקרב ספרים באותה סוגה.
            // החזירו את מספר העמודים של הספר שנבחר.
            throw new NotImplementedException("08");
        }

        // תרגיל 09: אם אין ספר בסוגה המבוקשת, החזירו -1; אחרת את מספר עמודי המומלץ.
        public static int BestRatedPagesOrMinusOne(Book[] books, string genre)
        {
            // TODO 09: אפשר להיעזר בפעולות הקודמות לאחר בדיקה שיש התאמה.
            throw new NotImplementedException("09");
        }

        // נתון לתרגיל 10. אין צורך לשנות את הפעולה הזו.
        public static int GenreIndex(string genre)
        {
            if (genre == "fantasy") return 0;
            if (genre == "mystery") return 1;
            if (genre == "science") return 2;
            return 3; // biography; כל סוגה בקלט היא אחת מארבע הסוגות הנתונות.
        }

        // תרגיל 10א: counts כבר קיים ואורכו 4. הוסיפו את הספר למונה המתאים.
        public static void AddToGenreCounts(int[] counts, Book b)
        {
            // TODO 10א: השתמשו ב־GenreIndex. מעדכנים את המערך שקיבלתם.
            throw new NotImplementedException("10a");
        }

        // תרגיל 10ב: החזירו מערך מונים חדש באורך 4, לפי הסדר שב־GenreIndex.
        public static int[] CountGenres(Book[] books)
        {
            // TODO 10ב: צרו מערך, עברו על הספרים והיעזרו ב־AddToGenreCounts.
            throw new NotImplementedException("10b");
        }

        // תרגיל 11: הדפיסו את מספר עמודי המומלץ ב־fantasy (או none), ואז 4 מונים.
        public static void ShowLibrarySummary(Book[] books)
        {
            // TODO 11: השתמשו ב־BestRatedPagesOrMinusOne וב־CountGenres.
            // הפלט המדויק והדוגמה מופיעים בדף התרגילים.
            throw new NotImplementedException("11");
        }
    }
}
