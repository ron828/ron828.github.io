using System;
using System.IO;
using System.Globalization;

namespace BookPractice
{
    // קובץ נתון. משלימים את התרגילים ב־Program.cs וב־Book.cs.
    // כל מערכי הספרים בבדיקות אינם ריקים; אין בדיקות null או סוגה לא מוכרת.
    public static class Tests
    {
        public static void RunAll()
        {
            Action[] sections = { Test01, Test02, Test03, Test04, Test05, Test06,
                Test07, Test08, Test09, Test10, Test11 };
            for (int i = 0; i < sections.Length; i++)
            {
                string number = (i + 1).ToString("00");
                try
                {
                    sections[i]();
                    Console.WriteLine(number + " PASSED");
                }
                catch (NotImplementedException ex)
                {
                    Console.WriteLine(number + " FAILED - " + Short(ex.Message) + " not implemented");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(number + " FAILED - " + Short(ex.Message));
                }
            }
        }


        private static Book B(string genre, int pages, int rating)
        {
            return new Book(genre, pages, rating);
        }

        private static Book[] Library()
        {
            return new Book[] {
                B("mystery", 180, 8), B("fantasy", 320, 7),
                B("fantasy", 240, 9), B("science", 210, 6)
            };
        }

        private static void Test01()
        {
            Equal("180\n8", Capture(() => Program.ShowBook(B("mystery", 180, 8))), "pages/rating");
            Equal("320\n7", Capture(() => Program.ShowBook(B("fantasy", 320, 7))), "pages/rating");
        }

        private static void Test02()
        {
            Book a = B("fantasy", 240, 9);
            Equal(true, a.SameGenre(B("fantasy", 320, 7)), "same genre");
            Equal(false, a.SameGenre(B("mystery", 240, 9)), "different genre");
            Equal(true, a.SameGenre(a), "same book");
        }

        private static void Test03()
        {
            Book a = B("fantasy", 240, 8);
            Equal(true, a.IsBetterRatedInSameGenre(B("fantasy", 320, 7)), "higher rating");
            Equal(false, a.IsBetterRatedInSameGenre(B("fantasy", 180, 9)), "lower rating");
            Equal(false, a.IsBetterRatedInSameGenre(B("fantasy", 300, 8)), "equal ratings");
            Equal(false, a.IsBetterRatedInSameGenre(B("mystery", 320, 7)), "different genre");
        }

        private static void Test04()
        {
            Equal("180\n320\n240\n210", Capture(() => Program.PrintAllPages(Library())), "04a pages/order");
            Equal("320\n240", Capture(() => Program.PrintFantasyPages(Library())), "04b fantasy");
            Book[] other = { B("mystery", 170, 5), B("biography", 350, 8) };
            Equal("170\n350", Capture(() => Program.PrintAllPages(other)), "04a pages/order");
            Equal("", Capture(() => Program.PrintFantasyPages(other)), "04b no fantasy");
        }

        private static void Test05()
        {
            Equal(2, Program.CountGenre(Library(), "fantasy"), "fantasy count");
            Equal(1, Program.CountGenre(Library(), "mystery"), "mystery count");
            Equal(0, Program.CountGenre(Library(), "biography"), "genre absent");
            Book[] one = { B("biography", 150, 4) };
            Equal(1, Program.CountGenre(one, "biography"), "one book");
        }

        private static void Test06()
        {
            Book[] middle = { B("fantasy", 400, 6), B("fantasy", 250, 9), B("fantasy", 100, 7) };
            Equal(9, Program.MaxRating(middle), "maximum rating");
            Book[] first = { B("mystery", 150, 10), B("mystery", 300, 2) };
            Equal(10, Program.MaxRating(first), "first is best rated");
            Book[] last = { B("science", 500, 1), B("science", 280, 8) };
            Equal(8, Program.MaxRating(last), "last is best rated");
            Book[] one = { B("biography", 170, 0) };
            Equal(0, Program.MaxRating(one), "one book/rating zero");
        }

        private static void Test07()
        {
            Book[] middle = { B("fantasy", 400, 6), B("fantasy", 250, 9), B("fantasy", 100, 7) };
            Equal(250, Program.BestRatedPages(middle), "pages of best rated");
            Book[] first = { B("mystery", 150, 10), B("mystery", 300, 2) };
            Equal(150, Program.BestRatedPages(first), "first is best rated");
            Book[] last = { B("science", 500, 1), B("science", 280, 8) };
            Equal(280, Program.BestRatedPages(last), "last is best rated");
            Book[] one = { B("biography", 170, 0) };
            Equal(170, Program.BestRatedPages(one), "one book/rating zero");
        }

        private static void Test08()
        {
            Equal(240, Program.BestRatedPagesInGenre(Library(), "fantasy"), "best fantasy pages");
            Equal(180, Program.BestRatedPagesInGenre(Library(), "mystery"), "one matching book");
            Book[] mixed = { B("fantasy", 500, 10), B("mystery", 170, 5),
                B("mystery", 260, 8), B("biography", 400, 9) };
            Equal(260, Program.BestRatedPagesInGenre(mixed, "mystery"), "ignore other genres");
        }

        private static void Test09()
        {
            Equal(-1, Program.BestRatedPagesOrMinusOne(Library(), "biography"), "genre absent");
            Equal(240, Program.BestRatedPagesOrMinusOne(Library(), "fantasy"), "best fantasy pages");
            Book[] mixed = { B("fantasy", 500, 10), B("mystery", 170, 5), B("mystery", 260, 8) };
            Equal(260, Program.BestRatedPagesOrMinusOne(mixed, "mystery"), "ignore other genres");
            Book[] zero = { B("biography", 130, 0) };
            Equal(130, Program.BestRatedPagesOrMinusOne(zero, "biography"), "rating zero is a match");
        }

        private static void Test10()
        {
            string[] genres = { "fantasy", "mystery", "science", "biography" };
            for (int i = 0; i < genres.Length; i++)
            {
                int[] counts = { 2, 4, 1, 3 };
                int[] expected = { 2, 4, 1, 3 };
                expected[i]++;
                Program.AddToGenreCounts(counts, B(genres[i], 200, 7));
                Counts(expected, counts, "10a " + genres[i]);
            }
            Counts(new int[] { 2, 1, 1, 0 }, Program.CountGenres(Library()), "10b all genres");
            Book[] other = { B("biography", 250, 8), B("biography", 300, 6), B("mystery", 190, 7) };
            Counts(new int[] { 0, 1, 0, 2 }, Program.CountGenres(other), "10b fresh counters");
        }

        private static void Test11()
        {
            Equal("240\nfantasy: 2\nmystery: 1\nscience: 1\nbiography: 0",
                Capture(() => Program.ShowLibrarySummary(Library())), "library summary");
            Book[] other = { B("mystery", 200, 8), B("biography", 300, 7) };
            Equal("none\nfantasy: 0\nmystery: 1\nscience: 0\nbiography: 1",
                Capture(() => Program.ShowLibrarySummary(other)), "summary/no fantasy");
        }

        private static string Capture(Action action)
        {
            TextWriter previous = Console.Out;
            using (StringWriter writer = new StringWriter(CultureInfo.InvariantCulture))
            {
                try
                {
                    Console.SetOut(writer);
                    action();
                }
                finally
                {
                    Console.SetOut(previous);
                }
                return writer.ToString().Replace("\r\n", "\n").TrimEnd('\n', '\r');
            }
        }

        private static void Equal<T>(T expected, T actual, string label)
        {
            if (!object.Equals(expected, actual))
                throw new Exception(label + ": expected " + Value(expected) + ", got " + Value(actual));
        }

        private static void Counts(int[] expected, int[] actual, string label)
        {
            if (actual == null)
                throw new Exception(label + ": expected int[4], got null");
            if (actual.Length != 4)
                throw new Exception(label + ": expected 4 counters, got " + actual.Length);
            for (int i = 0; i < 4; i++)
                Equal(expected[i], actual[i], label + " index " + i);
        }

        private static string Value(object value)
        {
            if (value == null) return "null";
            if (value is string) return "\"" + value.ToString().Replace("\n", " / ") + "\"";
            return value.ToString();
        }

        private static string Short(string message)
        {
            string line = message.Replace("\r", " ").Replace("\n", " / ");
            return line.Length <= 180 ? line : line.Substring(0, 177) + "...";
        }
    }
}
