using System;

namespace BookPractice
{
    public class Book
    {
        private string genre;
        private int pages;
        private int rating;

        // דירוג שלם מ־0 עד 10. דירוג גבוה יותר טוב יותר.
        public Book(string genre, int pages, int rating)
        {
            this.genre = genre;
            this.pages = pages;
            this.rating = rating;
        }

        public string GetGenre()
        {
            return this.genre;
        }

        public int GetPages()
        {
            return this.pages;
        }

        public int GetRating()
        {
            return this.rating;
        }

        // תרגיל 02: האם העצם המפעיל והספר other שייכים לאותה סוגה?
        public bool SameGenre(Book other)
        {
            // TODO 02: החליפו את שורת ה־throw במימוש שלכם.
            throw new NotImplementedException("02");
        }

        // תרגיל 03: אותה סוגה, ולמפעיל דירוג גבוה ממש מדירוגו של other.
        public bool IsBetterRatedInSameGenre(Book other)
        {
            // TODO 03: השתמשו גם בפעולה SameGenre שכתבתם.
            throw new NotImplementedException("03");
        }
    }
}
