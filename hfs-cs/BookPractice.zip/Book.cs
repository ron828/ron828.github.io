using System;

namespace BookPractice
{
    public class Book
    {
        private string genre;
        private int pages;
        private int rating;

        // Integer rating from 0 to 10 inclusive. Higher is better.
        public Book(string genre, int pages, int rating)
        {
            this.genre = genre;
            this.pages = pages;
            this.rating = rating;
        }

        public string GetGenre()
        {
            return this.genre;
        }

        public int GetPages()
        {
            return this.pages;
        }

        public int GetRating()
        {
            return this.rating;
        }

        // Exercise 02: Do this book and other have the same genre?
        public bool SameGenre(Book other)
        {
            // TODO 02: Replace the following throw with your code.
            throw new NotImplementedException("02");
        }

        // Exercise 03: Same genre, and this book's rating is strictly higher than other's.
        public bool IsBetterRatedInSameGenre(Book other)
        {
            // TODO 03: Reuse your SameGenre method.
            throw new NotImplementedException("03");
        }
    }
}
